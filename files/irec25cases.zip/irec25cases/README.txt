If you cannot ./Allrun or clean, do:
chmod +x Allrun
chmod +x Allclean
(this adjusts file permissions to make them executable)


If windows add a bunch of zone id files, run this command in the top directory and it will recursively remove them from subdirecotries.
find . -name "*:Zone.Identifier" -type f -delete
